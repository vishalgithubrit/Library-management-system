//DATA STRUCTURE PROJECT
#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
typedef struct link{
	int book_id;
	char book_name[100];
	char auth_name[100];
	int d,m,y,da,mo,ye;
	char edition[100];
	int isbn_no;
	struct link *next;
}node;

node *start;
int l,m,n;
void create(node *);
void display(node *);
void insert_first(node *);
void insert_last(node *);
void insert_any(node *);
void delete_first(node *);
void delete_last(node *);
void delete_any(node *);
void modify_record(node *);
void search_id(node *);
void search_name(node *);

void main()
{
	int ch;
	clrscr();
	start=(node *)malloc(sizeof(node));
	printf("\nDATA STRUCTURE PROJECT\n\n");
	do{
		printf("\nPRESS 1 TO CREATE: ");
		printf("\nPRESS 2 TO DISPLAY: ");
		printf("\nPRESS 3 TO INSERT AT FIRST POSITION: ");
		printf("\nPRESS 4 TO INSERT AT LAST POSITION: ");
		printf("\nPRESS 5 TO INSERT AT ANY POSITION: ");
		printf("\nPRESS 6 TO DELETE FROM FIRST POSITION: ");
		printf("\nPRESS 7 TO DELETE FROM LAST POSITION: ");
		printf("\nPRESS 8 TO DELTE FROM ANY POSITION: ");
		printf("\nPRESS 9 TO MODIFY THE RECORD: ");
		printf("\nPRESS 10 TO SEARCH BY CUSTOMER ID: ");
		printf("\nPRESS 11 TO SEARCH BY CUSTOMER NAME: ");
		printf("\nPRESS 12 TO EXIT: ");
		printf("\n\nNOW ENTER URS CHOICE: ");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:
					create(start);
					break;
			case 2:
					display(start);
					break;
			case 3:
					insert_first(start);
					break;
			case 4:
					insert_last(start);
					break;
			case 5:
					insert_any(start);
					break;
			case 6:
					delete_first(start);
					break;
			case 7:
					delete_last(start);
					break;
			case 8:
					delete_any(start);
					break;
			case 9:
					modify_record(start);
					break;
			case 10:
					search_id(start);
					break;
			case 11:
					search_name(start);
					break;
			case 12:
					exit(1);
			default:
					printf("\nWRONG CHOICE: ");
					getch();
					exit(1);
		}
	}while(ch!=12);
	getch();
}
void create(node *cur)
{
	char ans;
	printf("\nENTER BOOK ID: ");
	scanf("%d",&cur->book_id);
	printf("\nENTER BOOK NAME: ");
	fflush(stdin);
	gets(cur->book_name);
	printf("\nENTER AUTHORITY NAME: ");
	fflush(stdin);
	gets(cur->auth_name);
	printf("\nENTER THE DATE OF PUBLICATION: \n");
	printf("\nENTER DATE: ");
	scanf("%d",&cur->d);
	printf("\nENTER MONTH: ");
	scanf("%d",&cur->m);
	printf("\nENTER YEAR: ");
	scanf("%d",&cur->y);
	printf("\nENTER THE EDITION: ");
	fflush(stdin);
	gets(cur->edition);
	printf("\nENTER DATE OF ISSUE: \n");
	printf("\nENTER DATE: ");
	scanf("%d",&cur->da);
	printf("\nENTER MONTH: ");
	scanf("%d",&cur->mo);
	printf("\nENTER YEAR: ");
	scanf("%d",&cur->ye);
	printf("\nENTER ISBN NO: ");
	scanf("%d",&cur->isbn_no);
	printf("\nDO U WANT TO INSERT MORE(Y/N)? ");
	ans=getche();
	if(ans=='y'||ans=='Y')
	{
		cur->next=(node *)malloc(sizeof(node));
		create(cur->next);
	}
	else
		cur->next=NULL;
}
void display(node *cur)
{
	if(!cur)
		return;
	printf("\nBOOK ID: %-5d",cur->book_id);
	printf("\t");
	printf("BOOK_NAME: ");
	puts(cur->book_name);
	printf("\t");
	printf("AUTH_NAME: ");
	puts(cur->auth_name);
	printf("\t");
	printf("PUBLICATION: %d/%d/%d",cur->d,cur->m,cur->y);
	printf("\t");
	printf("EDITION: ");
	puts(cur->edition);
	printf("\t");
	printf("DATE OF ISSUE: %d/%d/%d",cur->da,cur->mo,cur->ye);
	printf("\t");
	printf("ISBN_NO: %d",cur->isbn_no);
	display(cur->next);
}

void insert_first(node *cur)
{
	node *newnode;
	newnode=(node *)malloc(sizeof(node));
	printf("\nENTER BOOK ID: ");
	scanf("%d",&newnode->book_id);
	printf("\nENTER BOOK NAME: ");
	fflush(stdin);
	gets(newnode->book_name);
	printf("\nENTER AUTHORITY NAME: ");
	fflush(stdin);
	gets(newnode->auth_name);
	printf("\nENTER THE DATE OF PUBLICATION: \n");
	printf("\nENTER DATE: ");
	scanf("%d",&newnode->d);
	printf("\nENTER MONTH: ");
	scanf("%d",&newnode->m);
	printf("\nENTER YEAR: ");
	scanf("%d",&newnode->y);
	printf("\nENTER THE EDITION: ");
	fflush(stdin);
	gets(newnode->edition);
	printf("\nENTER DATE OF ISSUE: \n");
	printf("\nENTER DATE: ");
	scanf("%d",&newnode->da);
	printf("\nENTER MONTH: ");
	scanf("%d",&newnode->mo);
	printf("\nENTER YEAR: ");
	scanf("%d",&newnode->ye);
	printf("\nENTER ISBN NO: ");
	scanf("%d",&newnode->isbn_no);
	newnode->next=start;
	start=newnode;
}

void insert_last(node *cur)
{
	node *newnode;
	newnode=(node *)malloc(sizeof(node));
	printf("\nENTER BOOK ID: ");
	scanf("%d",&newnode->book_id);
	printf("\nENTER BOOK NAME: ");
	fflush(stdin);
	gets(newnode->book_name);
	printf("\nENTER AUTHORITY NAME: ");
	fflush(stdin);
	gets(newnode->auth_name);
	printf("\nENTER THE DATE OF PUBLICATION: \n");
	printf("\nENTER DATE: ");
	scanf("%d",&newnode->d);
	printf("\nENTER MONTH: ");
	scanf("%d",&newnode->m);
	printf("\nENTER YEAR: ");
	scanf("%d",&newnode->y);
	printf("\nENTER THE EDITION: ");
	fflush(stdin);
	gets(newnode->edition);
	printf("\nENTER DATE OF ISSUE: \n");
	printf("\nENTER DATE: ");
	scanf("%d",&newnode->da);
	printf("\nENTER MONTH: ");
	scanf("%d",&newnode->mo);
	printf("\nENTER YEAR: ");
	scanf("%d",&newnode->ye);
	printf("\nENTER ISBN NO: ");
	scanf("%d",&newnode->isbn_no);
	while(cur->next!=NULL)
		cur=cur->next;
	cur->next=newnode;
	newnode->next=NULL;
}

void insert_any(node *cur)
{
	node *newnode;
	int pos,c=0;
	newnode=(node *)malloc(sizeof(node));
	printf("\nENTER POSITION: ");
	scanf("%d",&pos);
	if(pos==1)
	{
		insert_first(start);
		return;
	}
	while(cur!=NULL)
	{
		c++;
		if(c==pos-1)
			break;
		cur=cur->next;
	}
	if(pos>c+1)
	{
		printf("\nPOSITION IS INVALID....");
		return;
	}
	printf("\nENTER BOOK ID: ");
	scanf("%d",&newnode->book_id);
	printf("\nENTER BOOK NAME: ");
	fflush(stdin);
	gets(newnode->book_name);
	printf("\nENTER AUTHORITY NAME: ");
	fflush(stdin);
	gets(newnode->auth_name);
	printf("\nENTER THE DATE OF PUBLICATION: \n");
	printf("\nENTER DATE: ");
	scanf("%d",&newnode->d);
	printf("\nENTER MONTH: ");
	scanf("%d",&newnode->m);
	printf("\nENTER YEAR: ");
	scanf("%d",&newnode->y);
	printf("\nENTER THE EDITION: ");
	fflush(stdin);
	gets(newnode->edition);
	printf("\nENTER DATE OF ISSUE: \n");
	printf("\nENTER DATE: ");
	scanf("%d",&newnode->da);
	printf("\nENTER MONTH: ");
	scanf("%d",&newnode->mo);
	printf("\nENTER YEAR: ");
	scanf("%d",&newnode->ye);
	printf("\nENTER ISBN NO: ");
	scanf("%d",&newnode->isbn_no);
	newnode->next=cur->next;
	cur->next=newnode;
}

void delete_first(node *temp)
{
	start=start->next;
	free(temp);
}

void delete_last(node *temp)
{
	node *prev;
	while(temp->next!=NULL)
	{
		prev=temp;
		temp=temp->next;
	}
	prev->next=NULL;
	free(temp);
}

void delete_any(node *temp)
{
	node *prev;
	int c=0,pos;
	printf("\nENTER THE POSITION: ");
	scanf("%d",&pos);
	if(pos==1)
	{
		delete_first(start);
		return;
	}
	while(temp!=NULL)
	{
		c++;
		if(c==pos)
			break;
		prev=temp;
		temp=temp->next;
	}
	if(pos>c)
	{
		printf("\nCAN'T FIND");
		return;
	}
	prev->next=temp->next;
	free(temp);
}

void modify_record(node *cur)
{
	node *newnode;
	int flag=0;
	newnode=(node *)malloc(sizeof(node));
	printf("ENTER BOOK_ID: ");
	scanf("%d",&newnode->book_id);
	while(cur!=NULL)
	{
		if(newnode->book_id==cur->book_id)
		{
			flag=1;
			break;
		}
		cur=cur->next;
	}
	if(flag==1)
	{
	 /*	printf("\nENTER BOOK ID: ");
		scanf("%d",&newnode->book_id);
	printf("\nENTER BOOK NAME: ");
	fflush(stdin);
	gets(newnode->book_name);
	printf("\nENTER AUTHORITY NAME: ");
	fflush(stdin);
	gets(newnode->auth_name);
	printf("\nENTER THE DATE OF  PUBLICATION: \n");
	printf("\nENTER DATE: ");
	scanf("%d",&newnode->d);
	printf("\nENTER MONTH: ");
	scanf("%d",&newnode->m);
	printf("\nENTER YEAR: ");
	scanf("%d",&newnode->y);
	printf("\nENTER THE EDITION: ");
	fflush(stdin);
	gets(newnode->edition);
	printf("\nENTER DATE OF ISSUE: \n");
	printf("\nENTER DATE: ");
	scanf("%d",&newnode->da);
	printf("\nENTER MONTH: ");
	scanf("%d",&newnode->mo);
	printf("\nENTER YEAR: ");
	scanf("%d",&newnode->ye);
	printf("\nENTER ISBN NO: ");
	scanf("%d",&newnode->isbn_no);  */
		create(start);
		return;
	}
	else
		printf("\nNOT FOUND");
}

void search_id(node *cur)
{
	node *newnode;
	int flag=0;
	newnode=(node *)malloc(sizeof(node));
	printf("ENTER BOOK_ID: ");
	scanf("%d",&newnode->book_id);
	while(cur->next!=NULL)
	{
		if(newnode->book_id==cur->book_id)
		{
			flag=1;
			break;
		}
		cur=cur->next;
	}
	if(flag==1)
		printf("\nYES I HAVE FOUND IT");
	else
		printf("\nNOT FOUND");
}
void search_name(node *cur)
{
	node *newnode;
	int flag=0;
	newnode=(node *)malloc(sizeof(node));
	printf("\nENTER CUSTOMER NAME: ");
	fflush(stdin);
	gets(newnode->auth_name);
	while(cur->next!=NULL)
	{
		if(newnode->auth_name[100]==cur->auth_name[100])
		{
			flag=1;
			break;
		}
		cur=cur->next;
	}
	if(flag==1)
		printf("\nGOT IT");
	else
		printf("\nNOT FOUND");

}